# Detailed Setup Instructions

## Prerequisites
- Android Studio Hedgehog or later
- Android SDK 34
- Kotlin 1.9+
- ARM64 Android device (minSdk 26)

## Step 1: Stockfish Compilation

### Option A: Using NDK
```bash
# Download Android NDK
export ANDROID_NDK=/path/to/android-ndk

git clone https://github.com/official-stockfish/Stockfish.git
cd Stockfish/src

# Create Android makefile
cat > Android.mk << 'EOF'
LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)
LOCAL_MODULE := stockfish
LOCAL_SRC_FILES := $(wildcard *.cpp)
LOCAL_CPPFLAGS := -std=c++17 -O3 -DNDEBUG
include $(BUILD_EXECUTABLE)
EOF

$ANDROID_NDK/ndk-build NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=Android.mk APP_ABI=arm64-v8a

# Copy to project
cp libs/arm64-v8a/stockfish /path/to/ChessLens/app/src/main/jniLibs/arm64-v8a/libstockfish.so
```

### Option B: Pre-built Binary
Download pre-built Stockfish ARM64 from:
https://github.com/official-stockfish/Stockfish/releases

Rename to `libstockfish.so` and place in `app/src/main/jniLibs/arm64-v8a/`

## Step 2: Piece Templates

Create or download 64×64 PNG templates:

1. **Source images**: Use Wikimedia Commons chess SVGs
2. **Render to PNG**: 
   ```bash
   # Using ImageMagick
   convert -background none -density 96 -resize 64x64 white_pawn.svg P.png
   ```
3. **Place in**: `app/src/main/assets/templates/`

Required templates:
- White: P, N, B, R, Q, K
- Black: p, n, b, r, q, k
- Empty square (just board color)

## Step 3: Build & Deploy

1. Open project in Android Studio
2. File → Sync Project with Gradle Files
3. Connect ARM64 device (enable USB debugging)
4. Run → Run 'app'

## Step 4: Permissions

On first launch:
1. Grant "Display over other apps" permission
2. Grant screen capture permission
3. Grant notification permission (Android 13+)

## Troubleshooting

**"Stockfish binary not found"**
- Verify `libstockfish.so` exists in `app/src/main/jniLibs/arm64-v8a/`
- Check file is executable: `chmod +x libstockfish.so`
- Rebuild project: Build → Clean Project → Rebuild Project

**"Board not detected"**
- Ensure chessboard is clearly visible on screen
- Board should occupy at least 30% of screen
- Good lighting/contrast helps detection

**"Templates not loading"**
- Verify PNG files are in `app/src/main/assets/templates/`
- File names are case-sensitive (P.png ≠ p.png)
- Check for file corruption

## Performance Notes
- Peak RAM: ~120MB (under 150MB budget)
- CPU: 4 threads for Stockfish
- Capture: 1 FPS polling (not continuous)
- All bitmaps recycled immediately after use
