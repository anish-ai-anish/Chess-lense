# ChessLens - Offline Android Chess Analyzer

Complete offline chess position analyzer for Android (ARM64, minSdk 26).

## Features
- Screen capture via MediaProjection (1 FPS polling)
- Automatic chessboard detection & perspective warping
- Template-based piece classification (13 templates)
- Local Stockfish engine (UCI protocol)
- Floating overlay with draggable control pill
- Vector move arrow drawing

## Setup

### 1. Stockfish Binary
Compile Stockfish for Android ARM64:
```bash
git clone https://github.com/official-stockfish/Stockfish.git
cd Stockfish/src
make build ARCH=arm64-v8a COMP=clang
```

Rename to `libstockfish.so` and place at:
```
app/src/main/jniLibs/arm64-v8a/libstockfish.so
```

### 2. Piece Templates
Create 13 PNG files (64×64, transparent background) at:
```
app/src/main/assets/templates/
├── P.png  (White Pawn)
├── N.png  (White Knight)
├── B.png  (White Bishop)
├── R.png  (White Rook)
├── Q.png  (White Queen)
├── K.png  (White King)
├── p.png  (Black Pawn)
├── n.png  (Black Knight)
├── b.png  (Black Bishop)
├── r.png  (Black Rook)
├── q.png  (Black Queen)
├── k.png  (Black King)
└── empty.png  (Empty square)
```

Use standard chess piece images with transparent backgrounds.

### 3. Build
Open in Android Studio, sync Gradle, and run on an ARM64 device.

## Usage
1. Launch app
2. Grant overlay and screen capture permissions
3. Open any chess app/website
4. Tap the floating "Analyze" button
5. View the best move arrow and evaluation

## Architecture
- `ScreenCaptureService`: MediaProjection + VirtualDisplay + ImageReader
- `BoardVisionProcessor`: Board detection, warping, FEN generation
- `TemplateMatcherClassifier`: NCC-based piece recognition
- `StockfishEngineManager`: UCI protocol bridge
- `OverlayController`: Floating UI management
- `MoveArrowOverlayView`: Canvas-based arrow rendering
