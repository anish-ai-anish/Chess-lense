package com.chesslens.analyzer.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class FloatingControlView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : LinearLayout(context, attrs) {

    var onAnalyzeClick: (() -> Unit)? = null
    var onSideToggle: (() -> Unit)? = null
    var onFlipToggle: (() -> Unit)? = null
    var onCloseClick: (() -> Unit)? = null

    private lateinit var btnSide: TextView
    private lateinit var btnFlip: TextView
    private lateinit var tvEval: TextView

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var isDragging = false

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        val padding = dpToPx(8)
        setPadding(padding, padding, padding, padding)

        background = GradientDrawable().apply {
            setColor(Color.parseColor("#CC222222"))
            cornerRadius = dpToPx(20).toFloat()
            setStroke(dpToPx(1), Color.parseColor("#80FFFFFF"))
        }

        val btnAnalyze = createButton("🔍 Analyze", Color.parseColor("#4CAF50"))
        btnAnalyze.setOnClickListener { onAnalyzeClick?.invoke() }

        btnSide = createButton("Side: W", Color.parseColor("#2196F3"))
        btnSide.setOnClickListener { onSideToggle?.invoke() }

        btnFlip = createButton("Flip: Off", Color.parseColor("#FF9800"))
        btnFlip.setOnClickListener { onFlipToggle?.invoke() }

        tvEval = TextView(context).apply {
            text = "-- | --"
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(dpToPx(8), 0, dpToPx(8), 0)
        }

        val btnClose = createButton("✕", Color.parseColor("#F44336"))
        btnClose.setOnClickListener { onCloseClick?.invoke() }

        addView(btnAnalyze)
        addView(btnSide)
        addView(btnFlip)
        addView(tvEval)
        addView(btnClose)

        setupDrag()
    }

    private fun createButton(text: String, color: Int): TextView {
        return TextView(context).apply {
            this.text = text
            setTextColor(Color.WHITE)
            textSize = 11f
            gravity = Gravity.CENTER
            val paddingH = dpToPx(10)
            val paddingV = dpToPx(6)
            setPadding(paddingH, paddingV, paddingH, paddingV)

            val params = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
            params.setMargins(dpToPx(4))
            layoutParams = params

            background = GradientDrawable().apply {
                setColor(color)
                cornerRadius = dpToPx(12).toFloat()
            }

            minWidth = dpToPx(48)
            minHeight = dpToPx(32)
        }
    }

    private fun setupDrag() {
        setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    isDragging = false
                    val params = layoutParams as WindowManager.LayoutParams
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (!isDragging && (abs(dx) > 10 || abs(dy) > 10)) {
                        isDragging = true
                    }
                    if (isDragging) {
                        val params = layoutParams as WindowManager.LayoutParams
                        params.x = initialX + dx
                        params.y = initialY + dy
                        (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager)
                            .updateViewLayout(this@FloatingControlView, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    !isDragging
                }
                else -> false
            }
        }
    }

    fun updateSideButton(color: Char) {
        btnSide.text = "Side: ${color.uppercase()}"
    }

    fun updateFlipButton(flipped: Boolean) {
        btnFlip.text = "Flip: ${if (flipped) "On" else "Off"}"
    }

    fun updateEvaluation(evaluation: String) {
        tvEval.text = evaluation
    }

    private fun dpToPx(dp: Int): Int {
        return (dp * resources.displayMetrics.density).toInt()
    }
}
