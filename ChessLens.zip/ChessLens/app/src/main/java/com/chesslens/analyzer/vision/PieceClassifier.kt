package com.chesslens.analyzer.vision

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import com.chesslens.analyzer.model.Piece
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.sqrt

interface PieceClassifier {
    suspend fun classify(squareBitmap: Bitmap): Piece
}

class TemplateMatcherClassifier(private val context: Context) : PieceClassifier {

    private val templates: MutableMap<Piece, Bitmap> = mutableMapOf()
    private var initialized = false

    private suspend fun ensureInitialized() {
        if (initialized) return
        withContext(Dispatchers.IO) {
            val templateFiles = mapOf(
                Piece.WHITE_PAWN to "templates/P.png",
                Piece.WHITE_KNIGHT to "templates/N.png",
                Piece.WHITE_BISHOP to "templates/B.png",
                Piece.WHITE_ROOK to "templates/R.png",
                Piece.WHITE_WHITE_QUEEN to "templates/Q.png",
                Piece.WHITE_KING to "templates/K.png",
                Piece.BLACK_PAWN to "templates/p.png",
                Piece.BLACK_KNIGHT to "templates/n.png",
                Piece.BLACK_BISHOP to "templates/b.png",
                Piece.BLACK_ROOK to "templates/r.png",
                Piece.BLACK_QUEEN to "templates/q.png",
                Piece.BLACK_KING to "templates/k.png",
                Piece.EMPTY to "templates/empty.png"
            )

            templateFiles.forEach { (piece, path) ->
                try {
                    context.assets.open(path).use { stream ->
                        templates[piece] = BitmapFactory.decodeStream(stream)
                    }
                } catch (e: Exception) {
                    // Template missing
                }
            }
            initialized = true
        }
    }

    override suspend fun classify(squareBitmap: Bitmap): Piece {
        ensureInitialized()
        if (templates.isEmpty()) return Piece.EMPTY

        var bestPiece = Piece.EMPTY
        var bestScore = -1.0

        val inputFeatures = extractFeatures(squareBitmap)

        for ((piece, template) in templates) {
            val templateFeatures = extractFeatures(template)
            val score = normalizedCrossCorrelation(inputFeatures, templateFeatures)
            if (score > bestScore) {
                bestScore = score
                bestPiece = piece
            }
        }

        return bestPiece
    }

    private fun extractFeatures(bitmap: Bitmap): FloatArray {
        val size = 16
        val scaled = Bitmap.createScaledBitmap(bitmap, size, size, true)
        val pixels = IntArray(size * size)
        scaled.getPixels(pixels, 0, size, 0, 0, size, size)

        val features = FloatArray(size * size)
        for (i in pixels.indices) {
            val c = pixels[i]
            features[i] = (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f
        }

        if (scaled != bitmap) scaled.recycle()
        return features
    }

    private fun normalizedCrossCorrelation(f1: FloatArray, f2: FloatArray): Double {
        if (f1.size != f2.size) return -1.0

        val n = f1.size
        var sum1 = 0.0
        var sum2 = 0.0
        for (i in 0 until n) {
            sum1 += f1[i]
            sum2 += f2[i]
        }
        val mean1 = sum1 / n
        val mean2 = sum2 / n

        var numerator = 0.0
        var denom1 = 0.0
        var denom2 = 0.0

        for (i in 0 until n) {
            val diff1 = f1[i] - mean1
            val diff2 = f2[i] - mean2
            numerator += diff1 * diff2
            denom1 += diff1 * diff1
            denom2 += diff2 * diff2
        }

        val denominator = sqrt(denom1) * sqrt(denom2)
        return if (denominator == 0.0) 0.0 else numerator / denominator
    }
}

class TFLiteClassifierStub(private val context: Context) : PieceClassifier {
    override suspend fun classify(squareBitmap: Bitmap): Piece {
        // Future: Load TFLite model and run inference
        return Piece.EMPTY
    }
}
