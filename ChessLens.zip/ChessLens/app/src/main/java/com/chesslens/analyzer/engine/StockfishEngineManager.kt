package com.chesslens.analyzer.engine

import android.content.Context
import android.util.Log
import com.chesslens.analyzer.model.EngineResult
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter

class StockfishEngineManager(private val context: Context) {

    companion object {
        const val TAG = "StockfishEngine"
        const val BINARY_NAME = "libstockfish.so"
    }

    private var process: Process? = null
    private var writer: BufferedWriter? = null
    private var reader: BufferedReader? = null
    private val engineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _engineState = MutableStateFlow<EngineState>(EngineState.NotInitialized)
    val engineState: StateFlow<EngineState> = _engineState

    sealed class EngineState {
        object NotInitialized : EngineState()
        object Initializing : EngineState()
        object Ready : EngineState()
        data class Error(val message: String) : EngineState()
    }

    suspend fun initialize() = withContext(Dispatchers.IO) {
        if (_engineState.value is EngineState.Ready) return@withContext

        _engineState.value = EngineState.Initializing

        try {
            val binaryFile = extractBinary()
            binaryFile.setExecutable(true)

            process = ProcessBuilder(binaryFile.absolutePath)
                .redirectErrorStream(true)
                .start()

            writer = BufferedWriter(OutputStreamWriter(process!!.outputStream))
            reader = BufferedReader(InputStreamReader(process!!.inputStream))

            sendCommand("uci")
            waitForResponse("uciok", timeoutMs = 5000)

            sendCommand("setoption name Threads value 4")
            sendCommand("setoption name Hash value 64")
            sendCommand("setoption name MultiPV value 1")

            sendCommand("isready")
            waitForResponse("readyok", timeoutMs = 5000)

            _engineState.value = EngineState.Ready
        } catch (e: Exception) {
            _engineState.value = EngineState.Error(e.message ?: "Unknown error")
            shutdown()
        }
    }

    suspend fun getBestMove(fen: String, moveTimeMs: Long = 1000): EngineResult =
        withContext(Dispatchers.IO) {
            if (_engineState.value !is EngineState.Ready) {
                initialize()
            }

            val resultDeferred = CompletableDeferred<EngineResult>()

            val readerJob = launch {
                var bestMove: String? = null
                var scoreCp = 0
                var mateIn: Int? = null
                var depth = 0
                val pv = mutableListOf<String>()

                reader?.let { r ->
                    var line: String?
                    while (isActive && resultDeferred.isActive) {
                        line = r.readLine() ?: break
                        Log.d(TAG, "Engine: $line")

                        when {
                            line.startsWith("info depth") -> {
                                val depthMatch = Regex("depth (\d+)").find(line)
                                depth = depthMatch?.groupValues?.get(1)?.toIntOrNull() ?: depth

                                val scoreMatch = Regex("score cp (-?\d+)").find(line)
                                scoreMatch?.let { scoreCp = it.groupValues[1].toInt() }

                                val mateMatch = Regex("score mate (-?\d+)").find(line)
                                mateIn = mateMatch?.groupValues?.get(1)?.toIntOrNull()

                                val pvMatch = Regex("pv (.+)").find(line)
                                pvMatch?.let {
                                    pv.clear()
                                    pv.addAll(it.groupValues[1].split(" "))
                                }
                            }
                            line.startsWith("bestmove") -> {
                                bestMove = line.split(" ").getOrNull(1)
                                if (bestMove != null && bestMove != "(none)") {
                                    resultDeferred.complete(
                                        EngineResult(
                                            from = bestMove!!.substring(0, 2),
                                            to = bestMove!!.substring(2, 4),
                                            promotion = if (bestMove!!.length > 4) bestMove!![4] else null,
                                            scoreCp = scoreCp,
                                            mateIn = mateIn,
                                            depth = depth,
                                            pv = pv.toList()
                                        )
                                    )
                                } else {
                                    resultDeferred.completeExceptionally(
                                        IllegalStateException("No best move found")
                                    )
                                }
                            }
                        }
                    }
                }
            }

            sendCommand("position fen $fen")
            sendCommand("go movetime $moveTimeMs")

            try {
                withTimeout(moveTimeMs + 2000) {
                    resultDeferred.await()
                }
            } finally {
                readerJob.cancel()
            }
        }

    private fun extractBinary(): File {
        val filesDir = context.filesDir
        val binaryFile = File(filesDir, BINARY_NAME)

        if (binaryFile.exists() && binaryFile.length() > 0) {
            return binaryFile
        }

        val nativeLibDir = context.applicationInfo.nativeLibraryDir
        val sourceFile = File(nativeLibDir, BINARY_NAME)

        if (sourceFile.exists()) {
            sourceFile.copyTo(binaryFile, overwrite = true)
            return binaryFile
        }

        throw IllegalStateException("Stockfish binary not found in $nativeLibDir")
    }

    private suspend fun sendCommand(cmd: String) = withContext(Dispatchers.IO) {
        writer?.let {
            it.write(cmd)
            it.newLine()
            it.flush()
        }
    }

    private suspend fun waitForResponse(expected: String, timeoutMs: Long) =
        withContext(Dispatchers.IO) {
            withTimeout(timeoutMs) {
                reader?.let { r ->
                    var line: String?
                    while (true) {
                        line = r.readLine() ?: break
                        Log.d(TAG, "Handshake: $line")
                        if (line.contains(expected)) return@let
                    }
                }
            }
        }

    fun shutdown() {
        engineScope.launch {
            try {
                sendCommand("quit")
                delay(100)
                process?.destroy()
            } catch (e: Exception) {
                // Ignore
            } finally {
                process = null
                writer = null
                reader = null
                _engineState.value = EngineState.NotInitialized
            }
        }
    }
}
