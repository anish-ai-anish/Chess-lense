package com.chesslens.analyzer.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.WindowManager

class OverlayController(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var controlView: FloatingControlView? = null
    private var arrowView: MoveArrowOverlayView? = null

    private var isFlipped = false
    private var activeColor: Char = 'w'

    var onAnalyzeRequest: ((Boolean, Char) -> Unit)? = null
    var onCloseRequest: (() -> Unit)? = null

    fun showControlPill() {
        if (controlView != null) return

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 50
            y = 100
        }

        controlView = FloatingControlView(context).apply {
            onAnalyzeClick = { onAnalyzeRequest?.invoke(isFlipped, activeColor) }
            onSideToggle = {
                activeColor = if (activeColor == 'w') 'b' else 'w'
                updateSideButton(activeColor)
            }
            onFlipToggle = {
                isFlipped = !isFlipped
                updateFlipButton(isFlipped)
            }
            onCloseClick = { hideAll(); onCloseRequest?.invoke() }
        }

        windowManager.addView(controlView, params)
    }

    fun showArrowOverlay(boardBounds: android.graphics.Rect, fromSquare: String, toSquare: String, isFlipped: Boolean) {
        hideArrow()

        val params = WindowManager.LayoutParams(
            boardBounds.width(),
            boardBounds.height(),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = boardBounds.left
            y = boardBounds.top
        }

        arrowView = MoveArrowOverlayView(context, fromSquare, toSquare, isFlipped).apply {
            layoutParams = params
        }

        windowManager.addView(arrowView, params)
        arrowView?.postDelayed({ hideArrow() }, 5000)
    }

    fun updateEvaluation(evaluation: String) {
        controlView?.updateEvaluation(evaluation)
    }

    fun hideArrow() {
        arrowView?.let {
            windowManager.removeView(it)
            arrowView = null
        }
    }

    fun hideAll() {
        hideArrow()
        controlView?.let {
            windowManager.removeView(it)
            controlView = null
        }
    }

    fun isShowing(): Boolean = controlView != null
}
