package com.chesslens.analyzer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.chesslens.analyzer.capture.ScreenCaptureService
import com.chesslens.analyzer.databinding.ActivityMainBinding
import com.chesslens.analyzer.engine.StockfishEngineManager
import com.chesslens.analyzer.overlay.OverlayController
import com.chesslens.analyzer.vision.BoardVisionProcessor
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var overlayController: OverlayController
    private lateinit var engineManager: StockfishEngineManager
    private lateinit var visionProcessor: BoardVisionProcessor

    private val REQUEST_CODE_OVERLAY = 1001
    private val REQUEST_CODE_SCREEN_CAPTURE = 1002

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        overlayController = OverlayController(this)
        engineManager = StockfishEngineManager(this)
        visionProcessor = BoardVisionProcessor(this)

        binding.btnStartOverlay.setOnClickListener {
            checkPermissionsAndStart()
        }

        binding.btnTestEngine.setOnClickListener {
            testEngine()
        }

        lifecycleScope.launch {
            engineManager.engineState.collectLatest { state ->
                binding.tvStatus.text = when (state) {
                    is StockfishEngineManager.EngineState.NotInitialized -> "Engine: Not Ready"
                    is StockfishEngineManager.EngineState.Initializing -> "Engine: Initializing..."
                    is StockfishEngineManager.EngineState.Ready -> "Engine: Ready ✓"
                    is StockfishEngineManager.EngineState.Error -> "Engine: Error - ${state.message}"
                }
            }
        }
    }

    private fun checkPermissionsAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, REQUEST_CODE_OVERLAY)
            return
        }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(
            mpm.createScreenCaptureIntent(),
            REQUEST_CODE_SCREEN_CAPTURE
        )
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        when (requestCode) {
            REQUEST_CODE_OVERLAY -> {
                if (Settings.canDrawOverlays(this)) {
                    checkPermissionsAndStart()
                } else {
                    Toast.makeText(this, "Overlay permission required", Toast.LENGTH_SHORT).show()
                }
            }
            REQUEST_CODE_SCREEN_CAPTURE -> {
                if (resultCode == Activity.RESULT_OK && data != null) {
                    val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                        action = ScreenCaptureService.ACTION_START
                        putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                        putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        startForegroundService(serviceIntent)
                    } else {
                        startService(serviceIntent)
                    }

                    showFloatingUI()
                } else {
                    Toast.makeText(this, "Screen capture permission denied", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun showFloatingUI() {
        overlayController.onAnalyzeRequest = { isFlipped, activeColor ->
            analyzeCurrentScreen(isFlipped, activeColor)
        }
        overlayController.onCloseRequest = {
            stopService(Intent(this, ScreenCaptureService::class.java))
        }
        overlayController.showControlPill()
        finish()
    }

    private fun analyzeCurrentScreen(isFlipped: Boolean, activeColor: Char) {
        lifecycleScope.launch {
            try {
                val service = ScreenCaptureService.instance
                if (service == null) {
                    Toast.makeText(this@MainActivity, "Capture service not running", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                val frame = service.grabSingleFrame()
                if (frame == null) {
                    Toast.makeText(this@MainActivity, "Failed to capture frame", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                Toast.makeText(this@MainActivity, "Analyzing...", Toast.LENGTH_SHORT).show()

                // Detect board
                val detectedBoard = visionProcessor.detectBoard(frame)
                if (detectedBoard == null) {
                    Toast.makeText(this@MainActivity, "Board not detected", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                // Classify pieces
                val pieceMatrix = visionProcessor.classifyBoard(detectedBoard.warpedBoard)

                // Generate FEN
                val fen = visionProcessor.generateFEN(pieceMatrix, isFlipped, activeColor)

                // Get best move from Stockfish
                val result = engineManager.getBestMove(fen, 1000)

                // Update UI
                val evalText = if (result.mateIn != null) {
                    "M${result.mateIn} | ${result.from}-${result.to}"
                } else {
                    "${result.scoreCp / 100.0} | ${result.from}-${result.to}"
                }
                overlayController.updateEvaluation(evalText)

                // Show arrow
                overlayController.showArrowOverlay(
                    detectedBoard.screenBounds,
                    result.from,
                    result.to,
                    isFlipped
                )

            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this@MainActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun testEngine() {
        lifecycleScope.launch {
            engineManager.initialize()
            val result = engineManager.getBestMove(
                "r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3",
                1000
            )
            runOnUiThread {
                binding.tvStatus.text = "Best move: ${result.from}-${result.to} (${result.scoreCp}cp)"
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        engineManager.shutdown()
        overlayController.hideAll()
    }
}
