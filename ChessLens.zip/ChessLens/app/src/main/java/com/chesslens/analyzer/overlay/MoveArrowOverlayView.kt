package com.chesslens.analyzer.overlay

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class MoveArrowOverlayView @JvmOverloads constructor(
    context: Context,
    private val fromSquare: String,
    private val toSquare: String,
    private val isFlipped: Boolean = false,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF00E676")
        style = Paint.Style.STROKE
        strokeWidth = 12f
        strokeCap = Paint.Cap.ROUND
        isAntiAlias = true
    }

    private val arrowHeadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF00E676")
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#4000E676")
        style = Paint.Style.STROKE
        strokeWidth = 20f
        strokeCap = Paint.Cap.ROUND
        maskFilter = BlurMaskFilter(15f, BlurMaskFilter.Blur.NORMAL)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val start = squareToPixel(fromSquare, width.toFloat(), height.toFloat(), isFlipped)
        val end = squareToPixel(toSquare, width.toFloat(), height.toFloat(), isFlipped)

        canvas.drawLine(start.x, start.y, end.x, end.y, glowPaint)
        canvas.drawLine(start.x, start.y, end.x, end.y, paint)
        drawArrowhead(canvas, start, end)
    }

    private fun drawArrowhead(canvas: Canvas, start: PointF, end: PointF) {
        val angle = atan2((end.y - start.y).toDouble(), (end.x - start.x).toDouble())
        val arrowLength = 40f
        val arrowAngle = Math.PI / 6

        val path = Path()
        path.moveTo(end.x, end.y)

        val leftX = end.x - arrowLength * cos(angle - arrowAngle).toFloat()
        val leftY = end.y - arrowLength * sin(angle - arrowAngle).toFloat()
        path.lineTo(leftX, leftY)

        val rightX = end.x - arrowLength * cos(angle + arrowAngle).toFloat()
        val rightY = end.y - arrowLength * sin(angle + arrowAngle).toFloat()
        path.lineTo(rightX, rightY)

        path.close()
        canvas.drawPath(path, arrowHeadPaint)
    }

    private fun squareToPixel(square: String, width: Float, height: Float, flipped: Boolean): PointF {
        if (square.length < 2) return PointF(width / 2, height / 2)

        val file = square[0] - 'a'
        val rank = square[1] - '1'

        val col = if (flipped) 7 - file else file
        val row = if (flipped) rank else 7 - rank

        val cellWidth = width / 8f
        val cellHeight = height / 8f

        val centerX = col * cellWidth + cellWidth / 2
        val centerY = row * cellHeight + cellHeight / 2

        return PointF(centerX, centerY)
    }
}
