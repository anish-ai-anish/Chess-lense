package com.chesslens.analyzer.vision

import android.content.Context
import android.graphics.*
import com.chesslens.analyzer.model.DetectedBoard
import com.chesslens.analyzer.model.Piece
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.*

class BoardVisionProcessor(private val context: Context) {

    companion object {
        const val BOARD_SIZE = 512
        const val SQUARE_SIZE = 64
        const val TAG = "BoardVision"
    }

    private val classifier: PieceClassifier = TemplateMatcherClassifier(context)

    suspend fun detectBoard(screen: Bitmap): DetectedBoard? = withContext(Dispatchers.Default) {
        val detector = BoardContourDetector()
        val quad = detector.findBoardQuad(screen) ?: return@withContext null

        val warped = warpPerspective(screen, quad, BOARD_SIZE, BOARD_SIZE)
        val bounds = quad.boundingRect()

        screen.recycle()
        DetectedBoard(warped, bounds, 0.95f)
    }

    suspend fun classifyBoard(board: Bitmap): Array<Array<Piece>> = withContext(Dispatchers.Default) {
        val matrix = Array(8) { Array(8) { Piece.EMPTY } }

        for (row in 0 until 8) {
            for (col in 0 until 8) {
                val square = Bitmap.createBitmap(
                    board, col * SQUARE_SIZE, row * SQUARE_SIZE,
                    SQUARE_SIZE, SQUARE_SIZE
                )
                matrix[row][col] = classifier.classify(square)
                square.recycle()
            }
        }
        matrix
    }

    fun generateFEN(
        board: Array<Array<Piece>>,
        isFlipped: Boolean,
        activeColor: Char,
        castling: String = "KQkq",
        enPassant: String = "-",
        halfMove: Int = 0,
        fullMove: Int = 1
    ): String {
        val sb = StringBuilder()

        for (row in 0 until 8) {
            var emptyCount = 0
            for (col in 0 until 8) {
                val r = if (isFlipped) 7 - row else row
                val c = if (isFlipped) 7 - col else col

                val piece = board[r][c]
                if (piece == Piece.EMPTY) {
                    emptyCount++
                } else {
                    if (emptyCount > 0) {
                        sb.append(emptyCount)
                        emptyCount = 0
                    }
                    sb.append(piece.fenChar)
                }
            }
            if (emptyCount > 0) sb.append(emptyCount)
            if (row < 7) sb.append('/')
        }

        sb.append(' ').append(activeColor)
        sb.append(' ').append(if (castling.isEmpty()) "-" else castling)
        sb.append(' ').append(enPassant)
        sb.append(' ').append(halfMove)
        sb.append(' ').append(fullMove)

        return sb.toString()
    }

    private fun warpPerspective(src: Bitmap, quad: Quad, width: Int, height: Int): Bitmap {
        val dst = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(dst)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        val matrix = Matrix()
        val srcPoints = floatArrayOf(
            quad.topLeft.x, quad.topLeft.y,
            quad.topRight.x, quad.topRight.y,
            quad.bottomRight.x, quad.bottomRight.y,
            quad.bottomLeft.x, quad.bottomLeft.y
        )
        val dstPoints = floatArrayOf(
            0f, 0f,
            width.toFloat(), 0f,
            width.toFloat(), height.toFloat(),
            0f, height.toFloat()
        )
        matrix.setPolyToPoly(srcPoints, 0, dstPoints, 0, 4)
        canvas.drawBitmap(src, matrix, paint)
        return dst
    }
}

data class PointF(val x: Float, val y: Float)
data class Quad(
    val topLeft: PointF, val topRight: PointF,
    val bottomRight: PointF, val bottomLeft: PointF
) {
    fun boundingRect(): android.graphics.Rect {
        val left = minOf(topLeft.x, bottomLeft.x).roundToInt()
        val top = minOf(topLeft.y, topRight.y).roundToInt()
        val right = maxOf(topRight.x, bottomRight.x).roundToInt()
        val bottom = maxOf(bottomLeft.y, bottomRight.y).roundToInt()
        return android.graphics.Rect(left, top, right, bottom)
    }

    fun area(): Float {
        val w1 = distance(topLeft, topRight)
        val w2 = distance(bottomLeft, bottomRight)
        val h1 = distance(topLeft, bottomLeft)
        val h2 = distance(topRight, bottomRight)
        return ((w1 + w2) / 2f) * ((h1 + h2) / 2f)
    }

    private fun distance(a: PointF, b: PointF) = sqrt((a.x - b.x).pow(2) + (a.y - b.y).pow(2))
}

class BoardContourDetector {
    fun findBoardQuad(bitmap: Bitmap): Quad? {
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        val gray = FloatArray(width * height)
        for (i in pixels.indices) {
            val c = pixels[i]
            gray[i] = (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c))
        }

        val marginX = width * 0.1f
        val marginY = height * 0.1f

        var bestQuad: Quad? = null
        var maxScore = 0f

        val scales = listOf(0.3f, 0.4f, 0.5f, 0.6f, 0.7f)
        for (scale in scales) {
            val w = width * scale
            val h = w
            if (h > height * 0.8f) continue

            val step = width * 0.05f
            var y = marginY
            while (y + h < height - marginY) {
                var x = marginX
                while (x + w < width - marginX) {
                    val score = scoreRegion(gray, width, x, y, w, h)
                    if (score > maxScore) {
                        maxScore = score
                        bestQuad = Quad(
                            PointF(x, y),
                            PointF(x + w, y),
                            PointF(x + w, y + h),
                            PointF(x, y + h)
                        )
                    }
                    x += step
                }
                y += step
            }
        }

        return if (maxScore > 0.3f) bestQuad else null
    }

    private fun scoreRegion(gray: FloatArray, imgWidth: Int, x: Float, y: Float, w: Float, h: Float): Float {
        val cellW = w / 8f
        val cellH = h / 8f
        var totalVariance = 0f
        var validCells = 0

        for (row in 0 until 8) {
            for (col in 0 until 8) {
                val cx = (x + col * cellW).toInt()
                val cy = (y + row * cellH).toInt()
                val cw = cellW.toInt().coerceAtLeast(4)
                val ch = cellH.toInt().coerceAtLeast(4)

                if (cx + cw >= imgWidth || cy + ch >= gray.size / imgWidth) continue

                val mean = calculateMean(gray, imgWidth, cx, cy, cw, ch)
                val variance = calculateVariance(gray, imgWidth, cx, cy, cw, ch, mean)
                totalVariance += variance
                validCells++
            }
        }

        return if (validCells > 0) totalVariance / validCells else 0f
    }

    private fun calculateMean(gray: FloatArray, width: Int, x: Int, y: Int, w: Int, h: Int): Float {
        var sum = 0f
        var count = 0
        for (dy in 0 until h step 2) {
            for (dx in 0 until w step 2) {
                sum += gray[(y + dy) * width + (x + dx)]
                count++
            }
        }
        return sum / count
    }

    private fun calculateVariance(gray: FloatArray, width: Int, x: Int, y: Int, w: Int, h: Int, mean: Float): Float {
        var sum = 0f
        var count = 0
        for (dy in 0 until h step 2) {
            for (dx in 0 until w step 2) {
                val diff = gray[(y + dy) * width + (x + dx)] - mean
                sum += diff * diff
                count++
            }
        }
        return sum / count
    }
}
