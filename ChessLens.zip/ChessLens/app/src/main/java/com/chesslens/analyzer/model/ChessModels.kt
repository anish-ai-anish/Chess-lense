package com.chesslens.analyzer.model

enum class Piece(val fenChar: Char) {
    WHITE_PAWN('P'), WHITE_KNIGHT('N'), WHITE_BISHOP('B'),
    WHITE_ROOK('R'), WHITE_WHITE_QUEEN('Q'), WHITE_KING('K'),
    BLACK_PAWN('p'), BLACK_KNIGHT('n'), BLACK_BISHOP('b'),
    BLACK_ROOK('r'), BLACK_QUEEN('q'), BLACK_KING('k'),
    EMPTY('.')
}

data class DetectedBoard(
    val warpedBoard: android.graphics.Bitmap,
    val screenBounds: android.graphics.Rect,
    val confidence: Float
)

data class EngineResult(
    val from: String,
    val to: String,
    val promotion: Char?,
    val scoreCp: Int,
    val mateIn: Int?,
    val depth: Int,
    val pv: List<String>
)

data class AnalysisState(
    val fen: String,
    val result: EngineResult?,
    val isFlipped: Boolean
)
